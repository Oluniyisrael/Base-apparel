// import logo from './logo.svg';
import './App.css';
// import About from './Components/About/About';
import Body from './Components/Body/Body';
import Footer from './Components/footer/Footer';

function App() {
   
  return (
   <div>
       <Body />
      <Footer/>
      {/* <About/> */}
   </div>
  );
}

export default App;
